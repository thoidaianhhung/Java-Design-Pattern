package com.design.pattern.Factory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
